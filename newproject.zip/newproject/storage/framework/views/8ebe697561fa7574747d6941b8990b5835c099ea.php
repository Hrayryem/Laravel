<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <form action="<?php echo e(route('create_product')); ?>" method="post" <?php echo e(csrf_field()); ?> >
    <input type="text" name="name" placeholder="Product Name"><br>
    <input type="text" name="price" placeholder="Product Price"> <br>
    <textarea name="desc" placeholder="Product Description"></textarea><br>
    <input type="submit" value="Avelacnel">
    </form>
    
</body>
</html>