<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
  //  $products=Product::get();
 public function index(){
   return view('create_product');
 }
    public function create(){
        
    }
}
