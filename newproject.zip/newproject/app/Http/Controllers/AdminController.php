<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function index(){
        return view('Admin.admin');
    }
    public function morris(){
        return view('Admin.layouts.morris');
    }
    public function flot(){
        return view('Admin.layouts.flot');
    }
    public function inline(){
        return view('Admin.layouts.inlinecharts');
    }
    public function simple(){
        return view('Admin.layouts.simple');
    }
    public function date(){
        return view('Admin.layouts.date');
    }
    public function category(){
        $categorys=Category::get();
        return view('Admin.layouts.category',compact('categorys'));
    }
    public function create_category(Request $request){
        $this->validate($request, [
            'img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'enname'=>'required|max:20',
        ]);


        $imageName = time().'.'.$request->img->getClientOriginalExtension();
        $request->img->move(public_path('img'), $imageName);



//      $validate= Validator::make($request->all(),['enname'=>'required|email|max:20']);
//      if ($validate->fails()){
//
//          return back()->withErrors($validate->errors())->withInput();
//      }
      $category=Category::create(['enname'=>$request->enname,'runame'=>$request->runame,'img'=>$imageName]);
        return back()
            ->with('success','category create succesfully.');
      dd($category);
      ////$category->save();->nkari anuuny tanel pahel
        /// return back()''''''
        /// session with
    }
}
