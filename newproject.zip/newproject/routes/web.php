<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
Route::get('/ari','HomeController@account');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('', 'HomeController@index')->name('home');
Route::get('/', 'HomeController@index')->name('home');
Route::get('/product', 'ProductController@index')->name('product');
Route::post('/create_product','ProductController@create')->name('create_product');
Route::get('/admin','AdminController@index')->name('admin')->middleware('admin');
Route::get('/admin','AdminController@index')->name('admin')->middleware('admin');
Route::get('/morris','AdminController@morris')->name('morris');
Route::get('/flot','AdminController@flot')->name('flot');
Route::get('/inlinecharts','AdminController@inline')->name('inlinecharts');
Route::get('/simple','AdminController@simple')->name('simple');
Route::get('/date','AdminController@date')->name('date');
Route::get('/category','AdminController@category')->name('date');
Route::post('/create-category','AdminController@create_category')->name('create_category');


